#!/bin/bash
umount /dev/sda1
mount /dev/sda1 /mnt
RESULT=$?
counter=1

if [ $RESULT -eq 0 ]; then {
	cp /mnt/wawision.php /root/wawision.php
        sync

 	#php /root/generate_network.php
	#while [[ $counter -lt 10 ]]
	#do
	#	sleep 1
	#	echo 0 > /sys/class/leds/led0/brightness
	#	sleep 1
	#	echo 1 > /sys/class/leds/led0/brightness
	#done
} fi
umount /dev/sda1
