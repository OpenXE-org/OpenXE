<?php 
$config["serial"] = "999999999";
?>
