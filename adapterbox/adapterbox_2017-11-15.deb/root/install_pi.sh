#!/bin/bash
sudo /bin/bash
cd /root
scp sauterbe@192.168.0.25:/var/www/html/wawision-misc/adapterbox/src/root/* ./
apt-get update
apt-get install php5-cli php5-curl openssl

echo "/root/watchdog_pi.sh & exit 0;" > /etc/rc.local
chmod +x /etc/rc.local
chmod +x /root/watchdog_pi.sh

