<?php
include("/root/class.labelprinter.php");

          $printer = new LabelPrinter();
           $printer->Configure(203,50,18,3,0,6);
           $printer->Printpath("/dev/usb/lp0");
           $printer->Printamount(1);
           $printer->Line(3,3,0,3,"WaWision Testlabel");
           $printer->Output(1);

?>
