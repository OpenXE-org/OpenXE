#! /usr/bin/python

import serial
import time

def readLine(ser):
    eol = b'\r'
    leneol = len(eol)
    line = bytearray()
    while True:
    	c = ser.read(1)
        if c:
      		if c == eol:
        		break
      	     	else:
             		line += c
        else:
            break
    return bytes(line)

def logLine(line):
  logfile = open("/root/RFIDlog.txt", "w+")
  logfile.write(str(int(time.time())) + ";" + line + ";\n")
  logfile.flush
  logfile.close()

ser = serial.Serial('/dev/ttyUSB0')
ser.baudrate = 115200
ser.write(b'CNR INV\r')


oldScan = 0
oldLine = ""
while 1:
        line = readLine(ser)
        if line.startswith("IVF"):
                continue
        if line != oldLine:
                logLine(line)
                oldLine = line
                oldScan = time.time()
        elif (int(time.time()) - oldScan) > 10:
                logLine(line)
                oldScan = time.time()

ser.close()
