<?php

include "/root/wawision.php";


if($settings['wlan'])
{


} else {

  if($settings['dhcp'])
  {
    $file_content = "
	auto lo
	iface lo inet loopback
	iface eth0 inet dhcp";
  } else {
    $file_content = "
	auto lo
	iface lo inet loopback
	iface eth0 inet static
	address ".$settings['ip']."
	netmask ".$settings['subnetmask']."
	";
     if(isset($settings['gateway']))$file_content .= "gateway ".$settings['gateway'];
  }
}

if($settings['dns']!="")
	file_put_contents("/etc/resolv.conf","nameserver ".$settings['dns']);

file_put_contents("/etc/network/interfaces",$file_content);
