#!/bin/sh
/bin/bash /root/boot.sh
/sbin/modprobe usblp0
/sbin/modprobe pl2303
/sbin/modprobe uvcvideo
php /root/scanner.class.php
while :
do
if ps -ef | grep -v grep | grep adapterboxdaemon.php ; then
        sleep 10
else
	php /root/adapterboxdaemon.php &
	sleep 10
fi
done
