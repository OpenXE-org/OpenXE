var macPrinterServices = angular.module('macPrinterServices', []);

macPrinterServices.service('statistikService', ['$http', function($http) {
	
	this.getStatistik = function() {
		
	}
 
}]);

macPrinterServices.service('printerService', ['$http', function(){
	
}]);