<?php
/*	
add_filter( 'woocommerce_checkout_fields' , 'wawision_override_checkout_fields' );

function wawision_override_checkout_fields( $fields ) {	
	$billing_title = array(
		'label' => __('Anrede', 'wawision_importer'),
		'placeholder' => __('Auswählen', 'placeholder', 'wawision_importer'),
		'required' => true,
		'clear' => false,
		'type' => 'select',
		'options' => array(
			'mr' => __('Herr', 'wawision_importer' ),
			'mrs' => __('Frau', 'wawision_importer' )
		)
	);
	
	$fields['billing'] =  ['billing_title' => $billing_title] + $fields['billing'];
	
	// unset($fields['billing']['billing_company']);
	// unset($fields['shipping']['billing_company']);
	return $fields;
}





 //Update the order meta with field value
add_action( 'woocommerce_checkout_update_order_meta', 'wawision_checkout_field_update_order_meta' );

function wawision_checkout_field_update_order_meta( $order_id ) {
    if ( ! empty( $_POST['billing_title'] ) ) {
	    if ($_POST['billing_title'] == 'mr' || $_POST['billing_title'] == 'mrs') {
	    	update_post_meta( $order_id, 'billing_title', sanitize_text_field( $_POST['billing_title'] ) );
    	}
        
    }
    
}


 //Display field value on the order edit page
add_action( 'woocommerce_admin_order_data_after_billing_address', 'wawision_checkout_field_display_admin_order_meta', 10, 1 );

function wawision_checkout_field_display_admin_order_meta($order){
    echo '<p><strong>'.__('Anrede').':</strong> ' . get_post_meta( $order->id, 'billing_title', true ) . '</p>';
}
*/
