<?php
/*
Plugin Name: WaWision Importer
Description: WaWision Importer für WooCommerce
Version: 1.0
Author: Bastian Aigner
Author URI: http://bastiaigner.com/
*/

/*
    Copyright (C) 2016  Bastian Aigner / Initial Version

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
class WaWi_Importer

{
  var $POST;
  function __construct($POST)
  {
    $this->POST = $POST;
    // Make sure we don't expose any info if called directly
    if ( !function_exists( 'add_action' ) ) {
      echo 'I\'m a plugin :-)';
      exit;
    }


    // Error-Logging ausschalten, damit es zu keinen Fehlern beim Import kommt
    ini_set("log_errors", 1);
    ini_set("error_log", "php-error.log");


    include( plugin_dir_path( __FILE__ ) . 'options-panel.php');
    include( plugin_dir_path( __FILE__ ) . 'wawision-importer.class.php');
    include( plugin_dir_path( __FILE__ ) . 'checkout-fields.php');



    add_action( 'init', array($this,'wawision_add_endpoint') );
    add_action('parse_request', array($this, 'wawision_url_handler'));

    register_activation_hook(__FILE__,array($this, 'wawision_activate'));
    add_filter( 'query_vars', array($this, 'wawision_query_vars') );
    add_action( 'parse_request', array($this, 'wawision_parse_request') );
    add_action( 'add_meta_boxes', array('wawision_imported_checkbox') );
    add_action( 'save_post',array( 'wawision_imported_checkbox_meta_save') );
  }


  function wawision_url_handler() {

    //if(substr($_SERVER["REQUEST_URI"], 0, strlen('/wawision-import/')) === '/wawision-import/') {
    if(strpos($_SERVER["REQUEST_URI"],'/woocommerceimporter')!== false) {
      $importer = new WaWision_Importer($this->POST);

      exit();
    }

  }

  function wawision_add_endpoint() {

    //add_rewrite_rule( '^wc-api/v([1-3]{1})(.*)?', 'index.php?wc-api-version=$matches[1]&wc-api-route=$matches[2]', 'top' );
    //add_rewrite_rule('^woocommerceimporter/(.*)/?', 'index.php?wawision_api=1&module=import&action=$matches[1]', 'top');
    //flush_rewrite_rules();
    add_rewrite_rule('^woocommerceimporter/(.+)/?$', 'index.php?wawision_api=1&action=$matches[1]', 'top');

    //add_rewrite_rule('^woocommerceimporter/(.+)?', 'index.php?wawision_api=1&action=a$matches[1]', 'top');
    /*add_rewrite_rule('^woocommerceimporter/(.+)?', 'index.php?wawision_api=1&action=$matches[1]', 'top');
    add_rewrite_rule('woocommerceimporter/(.+)/?', 'index.php?wawision_api=1&action=$matches[1]', 'top');
    add_rewrite_rule('woocommerceimporter/(.+)?', 'index.php?wawision_api=1&action=$matches[1]', 'top');*/

    //add_rewrite_rule( '^woocommerceimporter/index.php?module=import&action=(.*)?', 'index.php?wawision_api=1&module=import&action=$matches[1]', 'top' );
    /*
    add_rewrite_rule( '^wc-api/v([1-3]{1})(.*)?', 'index.php?wc-api-version=$matches[1]&wc-api-route=$matches[2]', 'top' );
    add_rewrite_rule( 'woocommerceimporter', 'index.php?wawision_api=1', 'top' );
    add_rewrite_rule('^woocommerceimporter/(.*)/?', 'index.php?wawision_api=1', 'top');
    add_rewrite_rule('^woocommerceimporter(.*)/?', 'index.php?wawision_api=1', 'top');*/
  }

  function wawision_activate()
  {
    flush_rewrite_rules();
  }

  function wawision_query_vars( $query_vars ) {
    $query_vars[] = 'wawision_api';
    $query_vars[] = 'action';
    $query_vars[] = 'module';
    $query_vars[] = 'data';
    $query_vars[] = 'token';
    return $query_vars;
  }



  function wawision_parse_request( &$wp ) {
    if ( array_key_exists( 'wawision_api', $wp->query_vars ) ) {

      $importer = new WaWision_Importer($this->POST);
      exit();
    }
    return;
  }











  // Metabox, die bei der Detailansicht einer Bestellung im WooCommerce-Backend angezeigt wird
  // Damit kann man zum Debuggen einzelne Bestellungen nochmal in WaWision importieren


  // Metabox registrieren
  function wawision_imported_checkbox() {
    add_meta_box( 'wawision_imported_checkbox', 'WaWision', 'wawision_imported_checkbox_callback', 'shop_order', 'side', 'high');
  }




  // Metabox calllback fuer HTML-Content der Metabox ansich
  function wawision_imported_checkbox_callback( $post ) {
    wp_nonce_field( basename( __FILE__ ), 'wawision_nonce' );

    $stored_meta = get_post_meta( $post->ID, '_wawision_imported', true );

    ?>
    <p>
      <label for="meta-text" class="prfx-row-title">Bereits in WaWision importiert</label>
      <input type="checkbox" name="wawision-imported" <?php if ($stored_meta) {echo 'checked';} ?> />
    </p>

    <?php
  }


  // Callback beim Speichern des postes
  function wawision_imported_checkbox_meta_save( $post_id ) {

    // save status ueberpruefen
    $is_autosave = wp_is_post_autosave( $post_id );
    $is_revision = wp_is_post_revision( $post_id );
    $is_valid_nonce = ( isset( $_POST[ 'wawision_nonce' ] ) && wp_verify_nonce( $_POST[ 'wawision_nonce' ], basename( __FILE__ ) ) ) ? 'true' : 'false';

    // Abbrechen abhaengig von save status
    if ( $is_autosave || $is_revision || !$is_valid_nonce ) {
      return;
    }

    // post_meta updaten / loeschen
    if( isset( $_POST[ 'wawision-imported' ] ) ) {
      update_post_meta( $post_id, '_wawision_imported', true );
    } else {
      delete_post_meta($post_id, '_wawision_imported');
    }
  }


}
new WaWi_Importer($_POST);

