<?php
/*
    Copyright (C) 2016  Bastian Aigner / Initial Version

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/



error_reporting(E_ERROR | E_PARSE);
//ini_set('display_errors', FALSE);

require( plugin_dir_path( __FILE__ ) . 'lib/Aes.php');
//require( plugin_dir_path( __FILE__ ) . 'lib/aes.class.php');

class WaWision_Importer {

  // Instanz der AES-Verschluesselungsklasse wird beim Aufruff von __constuct initialisiert
  private $aes = NULL;
  var $POST;
  // Error-Variable. Array aus strings. wird beim Aufruf von sendResonse ausgegeben, wenn count > 0
  private $error = [];


  // WP_Query, basierend auf der die Auftrage gefetch'ed werden, die fuer wawision relevant sind.
  // wird von __construct initialisert.
  private $orderQuery;

  private $productCatTax = 'product_cat';


  // constructor: initialisert password, schaut, ob zugansdaten richtig, ruft funktion zum routen auf.

  function __construct($POST) {

    $this->POST = $POST;

    /*
        $posts = get_posts(array('numberposts' => -1, 'post_type' => 'shop_order') );

          foreach($posts as $p) :

           //   $meta = get_post_meta($p->ID, 'meta_key',true);
           echo 'update';
           update_post_meta($p->ID, '_wawision_imported', '1'); // key value aendern
          endforeach;


          return;
    */


    // orderQuery initialiserien
    $this->orderQuery = new WP_Query([
      'post_status' => ['wc-completed', 'wc-on-hold', 'wc-processing'], // Muss evtl. angepasst werden.
      'post_type' => 'shop_order',
      'posts_per_page' => 10, // Anzahl erstmal auf 3 begrenzt, da der Import nach WaWision so schon extrem lange dauert. TODO: Optimieren.
      'meta_query' => [[
        'key' => '_wawision_imported',
        'compare' => 'NOT EXISTS',
      ],
      ],
    ]);

    /*echo $_SERVER["REQUEST_URI"];
        print_r($_REQUEST);
        print_r($_GET);
    echo $_REQUEST['action'];*/

    // auth checken
    // WICHTIG! NIE AUSKOMMENTIEREN!
    $password = get_option('wawision_options')['wawision_password'];
    //$this->aes = new AES($password);
    $this->aes = new PhpAes\Aes($password);

    $this->checkAuth();

    // routes definieren
    $this->addRoute('auth', 'importAuth');
    $this->addRoute('getauftraegeanzahl', 'importGetAuftraegeAnzahl');
    $this->addRoute('getauftrag', 'importGetAuftrag');
    $this->addRoute('deleteauftrag', 'importDeleteAuftrag');
    $this->addRoute('updateauftrag', 'importUpdateAuftrag');
    $this->addRoute('sendarticle', 'importUpdateAuftrag');
    $this->addRoute('test', 'importTest');
    $this->addRoute('storniereauftrag', 'importStorniereAuftrag');

    $this->addRoute("sendlist","importSendList");
    $this->addRoute("sendlistlager","importSendListLager");

    //routen
    $this->routeRequest();

  }


  function importSendList()
  {
    $tmp = $this->catchRemoteCommand('data');
    $anzahl = 0;
    $opt = get_option('wawision_options');
    $opt = $opt['wawision_erm_steuersatz'];
    if(!$opt)$opt = 'ermaessigter-steuersatz';
    for($i=0;$i<count($tmp);$i++){

      $artikel = $tmp[$i]['artikel'];
      $nummer = $tmp[$i]['nummer'];

      $laststock = $tmp[$i]['restmenge'];
      $inaktiv = $tmp[$i]['inaktiv'];
      $shippingtime = $tmp[$i]['lieferzeitmanuell'];

      $hersteller = $tmp[$i]['hersteller'];
      $herstellerlink = $tmp[$i]['herstellerlink'];

      $name_de = $tmp[$i]['name_de'];
      $name_en = $tmp[$i]['name_en'];
      $description = html_entity_decode($tmp[$i]['uebersicht_de']);
      $description_en = html_entity_decode($tmp[$i]['uebersicht_en']);
      $preis = $tmp[$i]['preis'];

      $pseudopreis = $tmp[$i]['pseudopreis'];//*1.19;
      if($pseudopreis <= $preis)$pseudopreis = $preis;
      $steuersatz = $tmp[$i]['steuersatz'];
      if($steuersatz > 1.10){
        $steuersatz = 'normal';
      }
      else{
        $steuersatz = 'ermaessigt';
      }

      $lageranzahl = $tmp[$i]['anzahl_lager'];
      $pseudolager = trim($tmp[$i]['pseudolager']);

      if($pseudolager > 0) $lageranzahl=$pseudolager;
      if($tmp[$i]['ausverkauft']=="1"){
        $lageranzahl=0; $laststock="1";
      }

      if($inaktiv)$aktiv=0;
      else $aktiv=1;

      $product_id = 0;
      if($laststock!="1") $laststock=0;
      $product_id  = wc_get_product_id_by_sku($nummer);

      if($product_id)
      {
        wp_update_post(array('ID' => $product_id,'post_title'=>$name_de,'post_content'=>$description,'post_status'=>($aktiv?'publish':'private')));
      }
      else{
        //Neu anlegen
        $product_id = wp_insert_post(array('post_title'=>$name_de,'post_type'=>'product','post_status'=>($aktiv?'publish':'private'),'post_content'=>$description));
      }

      if($product_id){

        update_post_meta($product_id, '_sku',$nummer);
        update_post_meta($product_id, '_visibility','visible');
        update_post_meta($product_id, '_regular_price',number_format($pseudopreis,2,'.',''));
        update_post_meta($product_id, '_sale_price',number_format($preis,2,'.',''));
        update_post_meta($product_id, '_price',number_format($preis,2,'.',''));

        if($steuersatz == 'ermaessigt')update_post_meta($product_id,'_tax_class',  $opt);

        if($lageranzahl===0){
          update_post_meta($product_id, '_stock_status','outofstock');
          update_post_meta($product_id, '_manage_stock','yes');
        }
        elseif($lageranzahl===''){
          update_post_meta($product_id, '_stock_status','instock');
          update_post_meta($product_id, '_manage_stock','no');
        }
        else{
          update_post_meta($product_id, '_stock_status','instock');
          update_post_meta($product_id, '_manage_stock','yes');
        }
        $product = new WC_Product($product_id);
        if($product){
          if($lageranzahl!==''){
            $product->set_stock($lageranzahl);
          }
        }
      }

      if(isset($tmp[$i]['kompletter_kategorienbaum'])){
        $baum = $tmp[$i]['kompletter_kategorienbaum'];
        $this->updateKategorieBaum($baum);
      }

      if(isset($tmp[$i]['Dateien'])){
        $dateien = $tmp[$i]['Dateien'];
        $this->save_images($dateien, $product_id);
      }

      $chosenCats = array();
      if(isset($tmp[$i]['kategorien'])){

        $kategorien = $tmp[$i]['kategorien'];
        if(count($kategorien)>0){

          $allWpCategories = $terms = get_terms(
            array(
              'taxonomy' => $this->productCatTax,
              'hide_empty' => false
            )
          );

          $searchWpCategories = [];
          foreach($allWpCategories as $a){
            $searchWpCategories[] = html_entity_decode($a->slug);
          }

          foreach($kategorien as $k => $v){
            $slug = sanitize_title($v['name']);
            if(array_search($slug,$searchWpCategories)!==false){
              $chosenCats[] = $this->chooseKategorie($product_id, $slug,$v['name'] ,true );
            }
          }
        }
      }
      /* //Hauptkategorie soll nicht übertragen werden
      if(isset($tmp[$i]['kategoriename'])){
        $kat_name = $tmp[$i]['kategoriename'];
        $slug = sanitize_title($kat_name);
        $chosenCats[] = $this->chooseKategorie($product_id,  , $kat_name, true);
      }
      */
      $wpChosenCats = wp_get_post_terms($product_id,$this->productCatTax);

      if(count($wpChosenCats)>0){
        $finalCats = array();
        foreach ($wpChosenCats as $wcc){

          if(array_search($wcc->term_id,$chosenCats)!==false){
            $finalCats[] = $wcc->term_id;
          }
          else{
            $isWawi = isset(get_term_meta($wcc->term_id)['wawi']);
            if(!$isWawi){
              $finalCats[] = $wcc->term_id;
            }
          }
        }
        wp_set_post_terms( $product_id, $finalCats, $this->productCatTax, false);
      }
      $anzahl++;
    }

    // anzahl erfolgreicher updates
    $this->sendResponse(array($product,$anzahl,$nummer,$steuersatz, $preis));
    exit;
  }


  private function updateKategorieBaum($baum){

    $compareArr = [];
    $sortByIdArr = [];

    $validParents = [];
    $onlineShopBaum = [];

    foreach($baum as $value){
      // Eine Kategorie ist dann gültig wenn Sie unter der Kategorie Online-Shop hängt
      if($value['name'] == 'Online-Shop'){
        $validParents[] = $value['id'];
      }

      if(array_search($value['parent'],$validParents)!==false){
        $validParents[] = $value['id'];
        $onlineShopBaum[] = $value;
      }
    }
    $baum = $onlineShopBaum;

    foreach($baum as $key => $value){

      $slug = sanitize_title($value['name']);

      $compareArr[$slug] = $key;
      $sortByIdArr[intval($value['id'])] = $value;
    }

    $terms = get_terms(
      array(
        'taxonomy' => $this->productCatTax,
        'hide_empty' => false
      )
    );
    $deleteTerms = array();

    if(count($terms)>0){

      foreach($terms as $t){
        $deleteTerms[$t->slug] = $t->term_id;
      }

      foreach($terms as $t) {
        if(isset($compareArr[$t->slug])){
          unset($deleteTerms[$t->slug]);
        }
      }

      foreach($baum as $b){

        if( empty(term_exists($b['name'],$this->productCatTax)) ){
          //Kategorie hinzufügen
          $wawikat = $b;
          $wawiParentId = intval($wawikat['parent']);
          $parent = null;
          if($wawiParentId!=0){
            $parent = $sortByIdArr[$wawiParentId];
          }

          $this->insertWawiKategorie($wawikat, $parent);
        }
      }
    }
    else{
      foreach($baum as $wawikat){

        $wawiParentId = intval($wawikat['parent']);
        $parent = null;
        if($wawiParentId!=0){
          $parent = $sortByIdArr[$wawiParentId];
        }

        $this->insertWawiKategorie($wawikat, $parent);
      }
    }

    foreach($deleteTerms as $d){

      $isWawi = isset(get_term_meta($d)['wawi']);

      if($isWawi){
        wp_delete_term( $d, $this->productCatTax );
      }
    }
  }


  private function save_images($dateien, $post_id){

    $galleryMetaKey = '_product_image_gallery';
    $metaArr = [];
    $metaDeleteArr = [];
    $meta = get_post_meta( $post_id,$galleryMetaKey,true);
    $hasHauptbild = false;

    if(!empty($meta)){
      $metaArr = explode(',', $meta);
      $metaDeleteArr = $metaArr;
    }

    //Entweder das erste Shopbild (neue Logik) oder das Hauptbild(alte Logik) wird zum Hauptbild
    $mainPic = -1;
    foreach ($dateien as $datei){

      $stichwort = $datei['stichwort'];

      if($stichwort=='Shopbild' || $stichwort=='Hauptbild'){
        $attach_id = $this->save_image($datei['datei'], $datei['filename']);
      }

      if(!empty($attach_id)){

        if($stichwort=='Hauptbild'){

          if($mainPic==-1){
            $mainPic = $attach_id;
          }
          else{
            if(count($metaArr)==0 || array_search($mainPic, $metaArr)===false){
              $metaArr[] = $attach_id;
            }
            else{
              unset($metaDeleteArr[array_search($mainPic, $metaDeleteArr)]);
            }
            $mainPic = $attach_id;
          }
          $hasHauptbild = true;
        }

        if($stichwort=='Shopbild'){

          if($mainPic==-1){
            $mainPic = $attach_id;
            $hasHauptbild = true;
          }
          else{
            if(count($metaArr)==0 || array_search($attach_id, $metaArr)===false){
              $metaArr[] = $attach_id;
            }
            else{
              unset($metaDeleteArr[array_search($attach_id, $metaDeleteArr)]);
            }
          }
        }
      }
    }

    if($mainPic!=-1){
      set_post_thumbnail($post_id, $mainPic);
    }

    if(count($metaDeleteArr)>0){
      foreach($metaDeleteArr as $d){
        unset($metaArr[array_search($d,$metaArr)]);
      }
    }

    update_post_meta($post_id, $galleryMetaKey, implode(',',$metaArr));
    if(!$hasHauptbild){
      delete_post_thumbnail($post_id);
    }
  }


  private function save_image( $base64_img, $title ) {

    $upload_dir  = wp_upload_dir();
    $upload_path = str_replace( '/', DIRECTORY_SEPARATOR, $upload_dir['path'] ) . DIRECTORY_SEPARATOR;

    $img             = str_replace( 'data:image/jpeg;base64,', '', $base64_img );
    $img             = str_replace( ' ', '+', $img );
    $decoded         = base64_decode( $img );
    $file_type       = $this->getMimeType($title);
    $attach_id = null;
    $post_title = preg_replace('/\.[^.]+$/','', $title);

    $attachment = get_page_by_title($post_title, OBJECT, 'attachment');

    if(empty($attachment)){

      $upload_file = file_put_contents( $upload_path . $title, $decoded );

      if($upload_file!==false){
        $attachment = array(
          'post_mime_type' => $file_type,
          'post_title'     => $post_title,
          'post_content'   => '',
          'post_status'    => 'inherit',
          'guid'           => $upload_dir['url'] . '/'.$title
        );

        $attach_id = wp_insert_attachment( $attachment, $upload_dir['path'] . '/' . $title );

        if(!function_exists('wp_generate_attachment_metadata')){
          include_once( ABSPATH . 'wp-admin/includes/image.php' );
        }
        $attach_data = wp_generate_attachment_metadata( $attach_id, $upload_dir['path'] . '/' . $title );
        wp_update_attachment_metadata( $attach_id,  $attach_data );
      }
      return $attach_id;
    }
    else{
      return $attachment->ID;
    }
  }


  private function insertWawiKategorie($wawikat,$wawikatParent){

    $wpParentTerm = null;
    //Parent finden
    if(!empty($wawikatParent)){
      $wpParentTerm = term_exists( $wawikatParent['name'], $this->productCatTax);
    }
    $parentArr = null;
    if($wpParentTerm){
      $parentArr = array( 'parent'=> $wpParentTerm['term_id'] );

      $term = wp_insert_term(
        $wawikat['name'],
        $this->productCatTax,
        $parentArr
      );
      add_term_meta($term['term_id'],'wawi',true);
    }
  }


  private function chooseKategorie($postId, $slug, $name ,$appendIfMissing){

    $term = term_exists( $slug, 'product_cat');
    $successTermId = -1;

    if(empty($term)){
      $term =  wp_insert_term(
        $name,
        $this->productCatTax
      );
    }

    if(!empty($term)){
      $terms = array($term['term_id']);
      wp_set_post_terms( $postId, $terms, $this->productCatTax, $appendIfMissing);
      $successTermId = $term['term_id'];
    }
    return $successTermId;
  }

  private function getMimeType($imageName){

    $split = explode('.', $imageName);

    switch ($split[1]) {

      case 'gif';
        $typ = 'image/gif';
        break;
      case 'png':
        $typ = 'image/png';
        break;
      case 'jpg':
      case 'jpeg':
      default:
        $typ = 'image/jpeg';
    }
    return $typ;
  }


  function importSendListLager()
  {
    $tmp = $this->catchRemoteCommand('data');


    $anzahl = 0;
    for($i=0;$i<count($tmp);$i++)
    {
      $artikel = $tmp[$i]['artikel'];
      $nummer = $tmp[$i]['nummer'];
      $lageranzahl = $tmp[$i]['anzahl_lager'];
      $laststock = $tmp[$i]['restmenge'];
      $inaktiv = $tmp[$i]['inaktiv'];
      $shippingtime = $tmp[$i]['lieferzeitmanuell'];
      $pseudolager = trim($tmp[$i]['pseudolager']);
      if($pseudolager > 0) $lageranzahl=$pseudolager;

      if($inaktiv)$aktiv=0;
      else $aktiv=1;

      if($tmp[$i]['ausverkauft']=="1"){
        $lageranzahl=0; $laststock="1";
      }
      $product_id = 0;
      if($laststock!="1") $laststock=0;
      $product_id  = wc_get_product_id_by_sku($nummer);
      if($product_id)
      {
        $product = new WC_Product($product_id);
      }
      if($product)
      {
        $product->set_stock($lageranzahl);

      }
      $anzahl++;

    }

    // anzahl erfolgreicher updates
    $this->sendResponse(array($product,$anzahl,$nummer));
    exit;
  }

  // -------------------
  // |     HANDLERS    |
  // -------------------

  function importAuth() {
    $sentToken = $this->catchRemoteCommand('token', true);
    $wpToken = get_option('wawision_options')['wawision_token'];

    if ($sentToken == $wpToken) {
      //$this->writeToLog("auth ok");
      $this->sendResponse('success');
    } else {
      //$this->writeToLog("auth failed");
      $this->sendResponse(array('failed',$_REQUEST,$_POST));
    }
  }


  function importGetAuftraegeAnzahl() {

    $__tmp = $this->catchRemoteCommand('data');

    if(!empty($__tmp['nummer']))
    {
      $order = new WC_Order($__tmp['nummer']);
      if( !empty($order->get_id() ) )
      {
        $this->sendResponse(1);
      }else{
        $this->sendResponse(0);
      }
    }
    elseif( !empty($__tmp['ab_nummer']) ){

      $ab_nummer = $__tmp['ab_nummer'];

      $this->orderQuery = new WP_Query([
        'post_status' => ['wc-completed', 'wc-on-hold', 'wc-processing'], // Muss evtl. angepasst werden.
        'post_type' => 'shop_order'
      ]);

      $posts = $this->orderQuery->posts;

      $newPosts = array();
      foreach($posts as $p){
        if( $p->ID>=$ab_nummer )$newPosts[] = $p;
      }
      if(count($newPosts)>0){
        $this->orderQuery->posts = $newPosts;
        $this->orderQuery->post_count = count($newPosts);
      }
      $this->sendResponse($this->orderQuery->post_count);
    }
    else{

      $this->sendResponse($this->orderQuery->post_count);
    }
  }

  function importTest()
  {
    $tmp = $this->catchRemoteCommand('data');
    if(isset($tmp['deleteid']))delete_post_meta($tmp['deleteid'], '_wawision_imported');
    $order = new WC_Order($tmp['id']);
    $this->writeToLog("did get order id: {$order->get_id()}");


    $billing_title = get_post_meta($order->get_id() , 'billing_title', true );


    $cart['order'] = json_decode(json_encode($order),true);
    $cart['methods'] = get_class_methods($order);
//$cart['bla'] = array('get_total_discount'=>$order->get_total_discount(),'get_order_discount'=>$order->get_order_discount(),'get_discount_to_display'=>$order->get_discount_to_display() ,'get_used_coupons'=>$order->get_used_coupons(),'get_total_tax_refunded_by_rate_id'=>$order->get_total_tax_refunded_by_rate_id(),'get_total_tax_refunded'=>$order->get_total_tax_refunded(),'get_taxes'=>$order->get_taxes(),'get_item_tax'=>$order->get_item_tax());

    foreach($cart['methods'] as $method)
    {
      if(strpos($method,'get_') === 0)$cart['gets'][$method] = $order->$method();

    }

    $cart['auftrag'] = $order->get_id();
    $cart['gesamtsumme'] = $order->get_total();

    $cart['transaktionsnummer'] = $order->get_transaction_id();
    $cart['onlinebestellnummer'] = $order->get_order_number();

    $cart['versandkostenbrutto'] = $order->get_total_shipping()+$order->get_shipping_tax();
    //$cart['versandkostennetto'] = $order->get_total_shipping() - $order->get_shipping_tax(); // netto-versandkosten berechnen

    $cart['internebemerkung'] = $order->customer_message;



    /*
        if (empty($order->billing_company)) {
          $cart['name'] = $order->billing_first_name . ' ' . $order->billing_last_name;
          $warenkorb['anrede']= 'frau';
        } else {
          $cart['name'] = $order->billing_company;
          $cart['ansprechpartner'] = $order->billing_first_name . ' ' . $order->billing_last_name;
          $warenkorb['anrede']= 'firma';
        }
    */

    $cart['name'] = $order->billing_first_name . ' ' . $order->billing_last_name;
    $cart['anrede'] = ($billing_title == 'mrs') ? 'frau' : 'herr';
    if (!empty($order->billing_company)) {
      $cart['anrede'] = 'firma';
      $cart['ansprechpartner'] = $order->billing_first_name . ' ' . $order->billing_last_name;
      $cart['name'] = $order->billing_company;
    }




    // Anrede wird von WooCommerce nicht abgefragt -> lassen wir erstmal weg.


    $cart['strasse'] = $order->billing_address_1;
    $cart['adresszusatz'] = $order->billing_address_2;
    $cart['plz'] = $order->billing_postcode;
    $cart['ort'] = $order->billing_city;
    $cart['land'] = $order->billing_country;
    $cart['email'] = $order->billing_email;
    // affilate_ref, abteilung und steuerfrei lassen wir erstmal weg. wo ist das bei WC?

    /*
        switch ($order->payment_method) {
          case "bacs" : $cart['zahlungsweise'] = 'vorkasse'; break;
          case "cod" : $cart['zahlungsweise'] = 'nachnahme'; break;
          case "paypal" : $cart['zahlungsweise'] = 'paypal'; break;
          case "SaferpayCw_DirectDebits" : $cart['zahlungsweise'] = 'lastschrift'; break;
          case "SaferpayCw_OpenInvoice" : $cart['zahlungsweise'] = 'rechnung'; break;
          case "SaferpayCw_CreditCard" : $cart['zahlungsweise'] = 'kreditkarte'; break;
          default: $cart['zahlungsweise'] = 'unbekannt';
        }
    */
    switch($order->payment_method)
    {
      case 'cod':
        $cart['zahlungsweise'] = 'nachnahme';
        break;
      case 'bacs':
      case 'cheque':
        $cart['zahlungsweise'] = 'vorkasse';
        break;
      default:
        $cart['zahlungsweise'] = $order->payment_method;
        break;
    }



    // TODO Selbstabholung / Versandunternehmen

    $cart['bestelldatum'] = $order->order_date;
    // ustid gibt's nicht??
    $cart['ustid'] = get_post_meta($order->get_id(), '_billing_ustid', true);
    if($cart['ustid']=="") get_post_meta($order->get_id(), '_billing_vat_id', true);

    $cart['telefon'] = $order->billing_phone;
    // fax gibt's auch nicht


    $tempCart['lieferadresse_name'] = $order->shipping_first_name . ' ' . $order->shipping_last_name;

    if (empty($order->shipping_company) || strtolower($order->shipping_company) == 'herr' || strtolower($order->shipping_company) == 'herrn' || strtolower($order->shipping_company) == 'frau') {
      $tempCart['lieferadresse_name'] = $order->shipping_first_name . ' ' . $order->shipping_last_name;
    } else {
      $tempCart['lieferadresse_name'] = $order->shipping_company;
      $tempCart['lieferadresse_ansprechpartner'] = $order->shipping_first_name . ' ' . $order->shipping_last_name;
    }
    $tempCart['lieferadresse_strasse'] = $order->shipping_address_1;
    $tempCart['lieferadresse_adresszusatz'] =  $order->shipping_address_2;
    $tempCart['lieferadresse_plz'] = $order->shipping_postcode;
    $tempCart['lieferadresse_ort'] = $order->shipping_city;
    $tempCart['lieferadresse_land'] = $order->shipping_country;
    $tempCart['lieferadresse_email'] = $order->shipping_email;

    if ($tempCart['lieferadresse_name'] != $cart['name'] ||
      //$tempCart['lieferadresse_ansprechpartner'] != $cart['ansprechpartner'] ||
      $tempCart['lieferadresse_strasse'] != $cart['strasse'] ||
      $tempCart['lieferadresse_adresszusatz'] != $cart['adresszusatz'] ||
      $tempCart['lieferadresse_plz'] != $cart['plz'] ||
      $tempCart['lieferadresse_ort'] != $cart['ort'] ||
      $tempCart['lieferadresse_land'] != $cart['land'] ) {


      $cart['abweichendelieferadresse'] = '1';
      $cart['lieferadresse_name']  = $tempCart['lieferadresse_name'] ;
      //$cart['lieferadresse_ansprechpartner'] = $tempCart['lieferadresse_ansprechpartner'];
      $cart['lieferadresse_strasse'] = $tempCart['lieferadresse_strasse'];
      $cart['lieferadresse_adresszusatz'] = $tempCart['lieferadresse_adresszusatz'];
      $cart['lieferadresse_plz'] = $tempCart['lieferadresse_plz'];
      $cart['lieferadresse_ort'] = $tempCart['lieferadresse_ort'];
      $cart['lieferadresse_land'] = $tempCart['lieferadresse_land'];
      $cart['lieferadresse_email'] = $tempCart['lieferadresse_email'];
    }

    $steuerfrei = 1;

    $steuersatz_ermaessigt = false;
    $steuersatz_normal = false;
    $steuersatz=0;
    //$cart['steuersatz_ermaessigt'];
    //$cart['steuersatz_normal'];


    foreach ($order->get_items() as $item) {
      if($item['line_tax'] > 0)$steuerfrei = 0;
      $tempsteuersatz = 100*($item['line_tax'] / $item['line_total']);
      if($tempsteuersatz > 10)
      {
        if(round($tempsteuersatz) != 19)$cart['steuersatz_normal'] = round($tempsteuersatz,1);
      }elseif($steuersatz > 0)
      {
        if(round($tempsteuersatz) != 7)$cart['steuersatz_ermaessigt'] = round($tempsteuersatz,1);
      }
      $product = new WC_Product($item['product_id']);

      if (!empty($item['variation_id'])) {
        $product = new WC_Product_Variation($item['variation_id']);
      }

      /*
            var_dump($item);

            die();
      */

      $articleArray[] = array(
        'articleid' => $product->get_sku(), // wir nehmen nicht die Produkt-DB-ID, sondern die gleiche nummer wie sie in wawison eingetragen ist
        'name' => $item['name'],
        'price' => number_format(($item['line_total'] + $item['line_tax']) / $item['qty'],2,'.',''), // brauchen wir line_total o. line_subtotal?

        'quantity' => $item['qty'],
      );

      //var_dump($item);
    }
    if($steuerfrei)$cart['steuerfrei'] = 1;

    $cart['articlelist'] = $articleArray;

    $tmp[0]['id'] = $cart['auftrag'];
    $tmp[0]['sessionid'];
    $tmp[0]['logdatei'];
    $tmp[0]['warenkorb'] = base64_encode(serialize($cart));

    if ($this->isDebug()) {
      $tmp[0]['warenkorb'] = $cart;
    }

    $this->sendResponse($tmp);
  }

  function importGetAuftrag() {

    global $wpdb;

    $__tmp = $this->catchRemoteCommand('data');
    // order initialiseren mit der ID des ersten results der order Query

    if(!empty($__tmp['nummer']))
    {
      $order = new WC_Order($__tmp['nummer']);
    }
    elseif(!empty($__tmp['ab_nummer'])){

      $abNummer = $__tmp['ab_nummer'];

      $result = $wpdb->get_row("SELECT MIN(id) smallest, MAX(id) biggest FROM wp_posts WHERE post_type='shop_order' ");
      $smallestId = $result->smallest;
      $biggestId = $result->biggest;

      if($abNummer>$biggestId){
        $abNummer = $biggestId;
      }

      if($abNummer<$smallestId){
        $abNummer = $smallestId;
      }

      $order = new WC_Order($abNummer);
    }
    else{
      $order = new WC_Order($this->orderQuery->posts[0]->ID);
    }
    $billing_title = get_post_meta($order->get_id() , 'billing_title', true );


    //$cart['order'] = json_decode(json_encode($order),true);
    //$cart['methods'] = get_class_methods($order);
//$cart['bla'] = array('get_total_discount'=>$order->get_total_discount(),'get_order_discount'=>$order->get_order_discount(),'get_discount_to_display'=>$order->get_discount_to_display() ,'get_used_coupons'=>$order->get_used_coupons(),'get_total_tax_refunded_by_rate_id'=>$order->get_total_tax_refunded_by_rate_id(),'get_total_tax_refunded'=>$order->get_total_tax_refunded(),'get_taxes'=>$order->get_taxes(),'get_item_tax'=>$order->get_item_tax());

    //foreach($cart['methods'] as $method)
    //{
    //  if(strpos($method,'get_') === 0)$cart['gets'][$method] = $order->$method();
    //
    //}

    $cart['auftrag'] = $order->get_id();
    $cart['gesamtsumme'] = $order->get_total();

    $cart['transaktionsnummer'] = $order->get_transaction_id();
    $cart['onlinebestellnummer'] = $order->get_order_number();

    $cart['versandkostenbrutto'] = $order->get_total_shipping()+$order->get_shipping_tax();
    //$cart['versandkostennetto'] = $order->get_total_shipping() - $order->get_shipping_tax(); // netto-versandkosten berechnen

    $cart['internebemerkung'] = $order->customer_message;

    $discount_total = (float)$order->get_total_discount();
    $get_discount_tax = (float)$order->get_discount_tax();
    if($discount_total != 0)
    {
      if($get_discount_tax == 0)
      {
        $cart['rabattnetto'] = -abs((float)$discount_total);
      }else{
        $cart['rabattbrutto'] = -abs((float)$discount_total);
        $cart['rabattbrutto'] += -abs((float)$get_discount_tax);
      }
      $rabattarr = $order->get_used_coupons();
      if($rabattarr && is_array($rabattarr) && isset($rabattarr[0]) && (String)$rabattarr[0] !== '')
      {
        $cart['rabattname'] =  (String)$rabattarr[0];
      }

    }

    /*
        if (empty($order->billing_company)) {
          $cart['name'] = $order->billing_first_name . ' ' . $order->billing_last_name;
          $warenkorb['anrede']= 'frau';
        } else {
          $cart['name'] = $order->billing_company;
          $cart['ansprechpartner'] = $order->billing_first_name . ' ' . $order->billing_last_name;
          $warenkorb['anrede']= 'firma';
        }
    */

    $cart['name'] = $order->billing_first_name . ' ' . $order->billing_last_name;
    $cart['anrede'] = ($billing_title == 'mrs') ? 'frau' : 'herr';
    $anrede= get_post_meta($order->get_id(),'_billing_title',true);
    if($anrede == 'mr')$cart['anrede'] = 'herr';

    if (!empty($order->billing_company)) {
      $cart['anrede'] = 'firma';
      $cart['ansprechpartner'] = $order->billing_first_name . ' ' . $order->billing_last_name;
      $cart['name'] = $order->billing_company;
    }




    // Anrede wird von WooCommerce nicht abgefragt -> lassen wir erstmal weg.


    $cart['strasse'] = $order->billing_address_1 . $order->billing_address_2;
    $cart['plz'] = $order->billing_postcode;
    $cart['ort'] = $order->billing_city;
    $cart['land'] = $order->billing_country;
    $cart['email'] = $order->billing_email;
    // affilate_ref, abteilung und steuerfrei lassen wir erstmal weg. wo ist das bei WC?

    /*
        switch ($order->payment_method) {
          case "bacs" : $cart['zahlungsweise'] = 'vorkasse'; break;
          case "cod" : $cart['zahlungsweise'] = 'nachnahme'; break;
          case "paypal" : $cart['zahlungsweise'] = 'paypal'; break;
          case "SaferpayCw_DirectDebits" : $cart['zahlungsweise'] = 'lastschrift'; break;
          case "SaferpayCw_OpenInvoice" : $cart['zahlungsweise'] = 'rechnung'; break;
          case "SaferpayCw_CreditCard" : $cart['zahlungsweise'] = 'kreditkarte'; break;
          default: $cart['zahlungsweise'] = 'unbekannt';
        }
    */
    switch($order->payment_method)
    {
      case 'cod':
        $cart['zahlungsweise'] = 'nachnahme';
        break;
      case 'bacs':
      case 'cheque':
        $cart['zahlungsweise'] = 'vorkasse';
        break;
      default:
        $cart['zahlungsweise'] = $order->payment_method;
        break;
    }



    // TODO Selbstabholung / Versandunternehmen

    $cart['bestelldatum'] = $order->order_date;
    // ustid gibt's nicht??
    $cart['telefon'] = $order->billing_phone;
    // fax gibt's auch nicht


    $tempCart['lieferadresse_name'] = $order->shipping_first_name . ' ' . $order->shipping_last_name;

    if (empty($order->shipping_company)) {
      $tempCart['lieferadresse_name'] = $order->shipping_first_name . ' ' . $order->shipping_last_name;
    } else {
      $tempCart['lieferadresse_name'] = $order->shipping_company;
      $tempCart['lieferadresse_ansprechpartner'] = $order->shipping_first_name . ' ' . $order->shipping_last_name;
    }
    $tempCart['lieferadresse_strasse'] = $order->shipping_address_1 . $order->shipping_address_2;
    $tempCart['lieferadresse_plz'] = $order->shipping_postcode;
    $tempCart['lieferadresse_ort'] = $order->shipping_city;
    $tempCart['lieferadresse_land'] = $order->shipping_country;
    $tempCart['lieferadresse_email'] = $order->shipping_email;

    if ($tempCart['lieferadresse_name'] != $cart['name'] ||
      //$tempCart['lieferadresse_ansprechpartner'] != $cart['ansprechpartner'] ||
      $tempCart['lieferadresse_strasse'] != $cart['strasse'] ||
      $tempCart['lieferadresse_plz'] != $cart['plz'] ||
      $tempCart['lieferadresse_ort'] != $cart['ort'] ||
      $tempCart['lieferadresse_land'] != $cart['land'] ) {


      $cart['abweichendelieferadresse'] = '1';
      $cart['lieferadresse_name']  = $tempCart['lieferadresse_name'] ;
      //$cart['lieferadresse_ansprechpartner'] = $tempCart['lieferadresse_ansprechpartner'];
      $cart['lieferadresse_strasse'] = $tempCart['lieferadresse_strasse'];
      $cart['lieferadresse_plz'] = $tempCart['lieferadresse_plz'];
      $cart['lieferadresse_ort'] = $tempCart['lieferadresse_ort'];
      $cart['lieferadresse_land'] = $tempCart['lieferadresse_land'];
      $cart['lieferadresse_email'] = $tempCart['lieferadresse_email'];
    }

    $steuerfrei = 1;
    $steuersatz= 0;
    $steuersatz_ermaessigt = false;
    $steuersatz_normal = false;
    //$cart['steuersatz_ermaessigt'];
    //$cart['steuersatz_normal'];

    $cart['ustid'] = (String)get_post_meta($order->get_id(), '_billing_ustid', true);
    if($cart['ustid']==="")$cart['ustid'] = (String)get_post_meta($order->get_id(), '_billing_vat_id', true);
    foreach ($order->get_items() as $item) {
      if($item['line_tax'] > 0)$steuerfrei = 0;
      $tempsteuersatz = 100*($item['line_tax'] / $item['line_total']);
      if($tempsteuersatz > 10)
      {
        if(round($tempsteuersatz) != 19)$cart['steuersatz_normal'] = round($tempsteuersatz,1);
      }elseif($steuersatz > 0)
      {
        if(round($tempsteuersatz) != 7)$cart['steuersatz_ermaessigt'] = round($tempsteuersatz,1);
      }
      $product = new WC_Product($item['product_id']);

      if (!empty($item['variation_id'])) {
        $product = new WC_Product_Variation($item['variation_id']);
      }

      /*
            var_dump($item);

            die();
      */

      $articleArray[] = array(
        'articleid' => $product->get_sku(), // wir nehmen nicht die Produkt-DB-ID, sondern die gleiche nummer wie sie in wawison eingetragen ist
        'name' => $item['name'],
        'price' => number_format(($item['line_total'] + $item['line_tax']) / $item['qty'],2,'.',''), // brauchen wir line_total o. line_subtotal?

        'quantity' => $item['qty'],
      );

      //var_dump($item);
    }
    if($steuerfrei)
    {
      $cart['steuerfrei'] = 1;
      $cart['versandkostennetto'] = $order->get_total_shipping();
    }

    $cart['articlelist'] = $articleArray;

    $tmp[0]['id'] = $cart['auftrag'];
    $tmp[0]['sessionid'];
    $tmp[0]['logdatei'];
    $tmp[0]['warenkorb'] = base64_encode(serialize($cart));

    if ($this->isDebug()) {
      $tmp[0]['warenkorb'] = $cart;
    }

    $this->sendResponse($tmp);
  }

  function importDeleteAuftrag() {
    $orderId = $this->catchRemoteCommand('data')['auftrag'];

    update_post_meta($orderId, '_wawision_imported', '1'); // key value aendern

    $this->sendResponse('ok');
  }


  function importStorniereAuftrag()
  {
    $data = $this->catchRemoteCommand('data');

    $order = new WC_Order($data['auftrag']);
    if($order->ID)
    {
      $order->update_status( 'cancelled', "" );
    }
    $this->sendResponse('ok');
    exit;
  }

  function importUpdateAuftrag() {

    $data = $this->catchRemoteCommand('data');

    $order = new WC_Order($data['auftrag']);
    $paymentOk = $data['zahlung'];
    $shippingOk = $data['versand'];
    $trackingCode = $data['tracking'];


    if ($paymentOk == 'ok' || $paymentOk == '1')
      $paymentOk = true;


    if ($shippingOk == 'ok' || $shippingOk == '1')
      $shippingOk = true;

    if ($paymentOk)
      $order->payment_complete();

    if ($shippingOk)
      $order->update_status( 'completed', "Tracking code: $trackingCode" );

    exit;
  }





  // -------------------
  // |     ROUTING     |
  // -------------------



  // speichert die definierten routes

  private $routes = [];


  // fuegt route hinzu. arg0 = action name, arg1 = string des callback-function-names in dieser class

  function addRoute($action, $callback) {
    $this->routes[$action] = $callback;
  }


  // routet das request

  function routeRequest() {


    $action = $_REQUEST['action'];
    if(!$action)
    {
      if(strpos($_SERVER["REQUEST_URI"],'action='))
      {
        $action = substr($_SERVER["REQUEST_URI"],strpos($_SERVER["REQUEST_URI"],'action=')+7 );
        $actiona = explode('&',$action);
        $action = $actiona[0];
      }
    }


    //$this->writeToLog('route: ' . $action);

    if (array_key_exists($action, $this->routes)) {
      call_user_func(array($this, $this->routes[$action]));
    } else {
      $this->error[] = 'unknown action '.$action;
      $this->sendResponse(NULL);
    }

  }



  // -------------------
  // |     HELPERS     |
  // -------------------



  // SICHERHEITSKRITISCH
  // ueberprueft, ob der Token & Password richtig ist und bricht ab, wenn nicht.

  private function checkAuth() {

    if ($this->isDebug()) {return;} // debug darf alles

    $sentToken = $this->catchRemoteCommand('token', true);
    $wpToken = get_option('wawision_options')['wawision_token'];

    if ($sentToken != $wpToken) {

      $this->writeToLog("auth failed. wrong token. ");
      $this->sendResponse('failed');
    }
  }



  // holt sich base64 encoded wert mit dem key $value aus dem request, wird aes-decoded wenn $aes=true

  function catchRemoteCommand($value, $aes=false) {
    if(empty($_REQUEST[$value]))
    {
      $_REQUEST[$value] = $_POST[$value];
      /*if(isset($_POST[$value]))$_REQUEST[$value] = $_POST[$value];
      if(empty($_REQUEST[$value]))
      {
        if(isset($this->POST[$value]))$_REQUEST[$value] = $this->POST[$value];
      }*/
    }


    if ($aes) {
      return unserialize($this->aes->decrypt(base64_decode($_REQUEST[$value])));
    } else {
      return unserialize(base64_decode($_REQUEST[$value]));
    }
  }



  // Das ganze ausgeben. Davon abhängig, ob isDebug == true
  // Wenn Fehler aufgetreten sind, werden diese auch ausgegeben.

  function sendResponse($what, $aes = false) {

    if (!$this->isDebug()) {

      if(count($this->error)>0)
      {
        echo base64_encode(serialize("error: ".implode(',',$this->error)));
      } else {
        if ($aes) {
          echo base64_encode($aes->encrypt(serialize($what)));
        } else {
          echo base64_encode(serialize($what));
        }

      }

    } else {
      if(count($this->error)>0)
      {
        echo 'error:';
        var_dump($this->error);
      } else {
        var_dump($what);
      }
    }

    exit;
  }



  function writeToLog($what) {
    if ($this->isDebug()) {
      $debug = 'DBG';
    } else {
      $debug = 'RLS';
    }

    // Kann dann auskommentiert werden.
    file_put_contents('logs.txt', date('Y-m-d H:i:s: ', $_SERVER['REQUEST_TIME']) . $debug . ' ' . $what . PHP_EOL , FILE_APPEND);
  }


  // SICHERHEITSKRITISCH
  // sollen wir das ganze als Debug betrachten? Wenn JA, dann keine Prüfung der Token & Ausgabe
  // wird nicht base64 encoded

  function isDebug() {

    // ACHTUNG!!!
    // NUR ZUM DEBUGGEN - UMBEDINGT AENDERN!!! (einfach immer return false;)

    /*
        if (strpos( $_SERVER['HTTP_USER_AGENT'], 'Safari') !== false) {
          return true;
        }
    */
    return false;
  }
}
?>
